import { EasyLink } from './EasyLink';
export { EasyLink };
