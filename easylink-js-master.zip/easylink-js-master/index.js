const EasyLink = require('./lib/src').EasyLink

module.exports = EasyLink
